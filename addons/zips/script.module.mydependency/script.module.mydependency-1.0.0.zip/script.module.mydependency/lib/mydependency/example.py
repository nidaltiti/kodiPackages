def hello_world():
    return "Hello from My Dependency Module!"
